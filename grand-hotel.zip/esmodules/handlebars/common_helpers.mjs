// Хелперы под конкретную систему
export const registerHandlebarsCommonHelpers = async function () {

}