// https://foundryvtt.wiki/en/development/guides/handling-data

export const registerSystemSettings = function() {

};