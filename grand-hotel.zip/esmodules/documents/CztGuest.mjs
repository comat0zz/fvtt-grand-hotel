/**
 * Extend the basic Actor
 * @extends {Actor}
 */
export default class CztGuest extends Actor {
  /*  
  _onUpdate(changed, options, userId) { 
      return super._onUpdate(changed, options, userId)
    } */
  };